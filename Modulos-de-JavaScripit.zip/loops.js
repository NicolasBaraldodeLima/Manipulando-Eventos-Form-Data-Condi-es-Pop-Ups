
var num=new Array();
	var i;
	for(i=0; i<10; i++){
		num[i]=0;
	}
	for(i=0; i<10; i++){
		document.write(num[i]+"<br>");
	}




